class TestConfig {
  // Purely for OTP-free testing (yielding 123456)
  static final List<String> testMobileNumbers = [
    '9999999999',
    '7339244560',
    '6383436841',
    '9346234886',
    '9112768829',
    '7349625941',
  ];

  static bool isTestNumber(String mobileNumber) {
    final clean = mobileNumber.replaceAll(RegExp(r'\D'), '');
    return testMobileNumbers.any((n) => clean.endsWith(n) || n.endsWith(clean));
  }
}
