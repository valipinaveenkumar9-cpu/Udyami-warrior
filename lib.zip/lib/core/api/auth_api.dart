import 'api_client.dart';

class AuthAPI {
  final ApiClient _api = ApiClient();

  Future<dynamic> sendOtp(String mobileNumber, String purpose) async {
    return await _api.post('/auth/send-otp', {
      'mobileNumber': mobileNumber,
      'purpose': purpose,
    });
  }

  Future<dynamic> verifyOtp(String mobileNumber, String otp, String purpose) async {
    return await _api.post('/auth/verify-otp', {
      'mobileNumber': mobileNumber,
      'otp': otp,
      'purpose': purpose,
    });
  }

  Future<dynamic> login(String mobileNumber, {String? otp, String? verificationId, bool? testMode}) async {
    final body = <String, dynamic>{
      'mobileNumber': mobileNumber,
    };
    
    if (testMode == true) {
      body['testMode'] = true;
    }

    if (verificationId != null && verificationId.isNotEmpty) {
      body['verificationId'] = verificationId;
    }

    if (otp != null && otp.isNotEmpty) {
      body['otp'] = otp;
    }
    
    return await _api.post('/auth/loginUser', body);
  }

  Future<bool> checkUserExists(String mobileNumber) async {
    try {
      print('DEV DEBUG - checkUserExists - Checking DB for mobile: $mobileNumber');
      
      // Strict database check WITHOUT testMode so backend doesn't mock-accept unregistered test numbers
      try {
        final res = await _api.post('/auth/loginUser', {
          'mobileNumber': mobileNumber,
          // Intentionally NO testMode here
        });
        if (res != null && res is Map) {
          final success = res['success'] == true || res['accessToken'] != null || res['user'] != null;
          final errorMsg = (res['message'] ?? res['error'] ?? '').toString().toLowerCase();
          
          if (success && !errorMsg.contains('invalid') && !errorMsg.contains('not found') && !errorMsg.contains('not registered') && !errorMsg.contains('does not exist') && !errorMsg.contains('no user')) {
            print('DEV DEBUG - checkUserExists - User verified in DB');
            return true;
          }
        }
      } catch (_) {}

      print('DEV DEBUG - checkUserExists - User NOT found in DB');
      return false;
    } catch (e) {
      print('DEV DEBUG - error checking user exists: $e');
      return false;
    }
  }

  Future<dynamic> createUser(Map<String, dynamic> data) async {
    return await _api.post('/auth/createUser', data);
  }

  Future<dynamic> createUserProfile(Map<String, dynamic> data) async {
    return await _api.post('/userprofile/createUserProfile', data);
  }
}
