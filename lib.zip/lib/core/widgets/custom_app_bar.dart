import 'package:flutter/material.dart';
import 'package:uk_circle_partners/core/thems/app_colors.dart';
import '../../main.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../utils/session_manager.dart';
import '../../features/profile/presentation/profile_screen.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final VoidCallback? onRefresh;
  final bool showBackArrow;

  const CustomAppBar({super.key, this.onRefresh, this.showBackArrow = true});

  @override
  Widget build(BuildContext context) {
    final canPop = showBackArrow && (ModalRoute.of(context)?.canPop ?? false);

    return AppBar(
      backgroundColor: Theme.of(context).colorScheme.surface,
      elevation: 0,
      leadingWidth: canPop ? 56 : 140, // Enough width for the logo if not popping
      leading: canPop
          ? IconButton(
              icon: Icon(Icons.arrow_back, color: Theme.of(context).colorScheme.onSurface),
              onPressed: () => Navigator.pop(context),
            )
          : Padding(
              padding: EdgeInsets.only(left: 16.0, top: 8.0, bottom: 8.0),
              child: Image.asset(
                'assets/logo/uk_logo_white_bg_1584x672.png',
                fit: BoxFit.contain,
                alignment: Alignment.centerLeft,
              ),
            ),
      title: canPop
          ? Image.asset(
              'assets/logo/uk_logo_white_bg_1584x672.png',
              height: 32,
              fit: BoxFit.contain,
              alignment: Alignment.centerLeft,
            )
          : SizedBox.shrink(),
      centerTitle: false,
      actions: [
        if (onRefresh != null)
          IconButton(
            icon: Icon(Icons.refresh, color: Theme.of(context).colorScheme.onSurface),
            onPressed: onRefresh,
          ),
        ValueListenableBuilder<ThemeMode>(
          valueListenable: appThemeNotifier,
          builder: (context, currentMode, _) {
            final isDark = currentMode == ThemeMode.dark;
            return IconButton(
              icon: Icon(
                isDark ? Icons.light_mode : Icons.dark_mode_outlined,
                color: Theme.of(context).colorScheme.onSurface,
              ),
              onPressed: () {
                appThemeNotifier.value = isDark ? ThemeMode.light : ThemeMode.dark;
              },
            );
          },
        ),
        Container(
          margin: EdgeInsets.only(right: 4),
          child: IconButton(
            icon: Icon(Icons.notifications_none, color: Theme.of(context).colorScheme.onSurface),
            onPressed: () => _showNotificationsBottomSheet(context),
          ),
        ),
        Container(
          margin: EdgeInsets.only(right: 12),
          child: IconButton(
            icon: Icon(Icons.menu, color: Theme.of(context).colorScheme.onSurface),
            onPressed: () => _showMenuBottomSheet(context),
          ),
        ),
      ],
    );
  }

  void _showNotificationsBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: context.colors.transparent,
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SizedBox(height: 24),
              Text('Notifications', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface)),
              SizedBox(height: 16),
              ListTile(
                leading: CircleAvatar(backgroundColor: Colors.blue.shade100, child: Icon(Icons.check, color: Colors.blue)),
                title: Text('Lead Approved', style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface)),
                subtitle: Text('Ramesh Kumar was approved.', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7))),
              ),
              ListTile(
                leading: CircleAvatar(backgroundColor: Colors.green.shade100, child: Icon(Icons.monetization_on, color: Colors.green)),
                title: Text('Points Earned', style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface)),
                subtitle: Text('You earned +50 points today.', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7))),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showMenuBottomSheet(BuildContext context) {
    final user = SessionManager.user;
    final name = user?['name'] ?? 'Rahul Sharma';
    final email = user?['email'] ?? 'rahul.s@example.com';
    
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Menu',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(24),
              bottomLeft: Radius.circular(24),
            ),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.85,
              height: double.infinity,
              padding: const EdgeInsets.only(top: 48, left: 8, right: 8, bottom: 32),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
              
              // --- User Profile Header ---
              GestureDetector(
                onTap: () {
                  Navigator.pop(context); // Close the bottom sheet
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ProfileScreen()),
                  );
                },
                child: Center(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 15,
                          offset: const Offset(0, 5),
                        ),
                      ],
                      border: Border.all(color: Colors.grey.withValues(alpha: 0.2)),
                    ),
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                          child: ValueListenableBuilder<int>(
                            valueListenable: SessionManager.profileUpdateNotifier,
                            builder: (context, _, __) {
                              return Column(
                                children: [
                                  // Profile Avatar
                                  CircleAvatar(
                                    radius: 42,
                                    backgroundColor: Colors.indigo,
                                    child: Text(
                                      SessionManager.userName.isNotEmpty ? SessionManager.userName.substring(0, 1).toUpperCase() + (SessionManager.userName.contains(' ') ? SessionManager.userName.split(' ')[1].substring(0, 1).toUpperCase() : '') : 'NK',
                                      style: TextStyle(
                                        fontSize: 28,
                                        fontWeight: FontWeight.bold,
                                        color: context.colors.cardBackground,
                                      ),
                                    ),
                                  ),

                                  const SizedBox(height: 16),

                                  // Name
                                  Text(
                                    SessionManager.userName,
                                    style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),

                                  const SizedBox(height: 6),

                                  // Member ID
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: Colors.indigo.shade50,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      SessionManager.memberId,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: Colors.indigo,
                                      ),
                                    ),
                                  ),

                                  const SizedBox(height: 14),

                                  // Ward
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(Icons.location_on_rounded, size: 18, color: Colors.grey),
                                      const SizedBox(width: 4),
                                      Text(
                                        SessionManager.userWard,
                                        style: const TextStyle(
                                          fontSize: 15,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ],
                                  ),

                                  const SizedBox(height: 8),

                                  // Tier
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                                    decoration: BoxDecoration(
                                      color: context.colors.orangeLight,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(Icons.workspace_premium, color: Colors.amber, size: 18),
                                        const SizedBox(width: 6),
                                        Text(
                                          SessionManager.userTier,
                                          style: const TextStyle(
                                            color: Colors.amber,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(height: 20),

                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 24),
                                    child: Text(
                                      'Show this when you introduce yourself.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }
                          ),
                        ),
                        Positioned(
                          top: 12,
                          right: 12,
                          child: IconButton(
                            icon: const Icon(Icons.edit, color: Colors.grey),
                            onPressed: () {
                              _showEditProfileDialog(context);
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              
              SizedBox(height: 24),
              
              // --- Menu Items ---
              _buildMenuItem(context, Icons.settings_outlined, 'Settings', () => Navigator.pop(context)),
              _buildMenuItem(context, Icons.help_outline, 'Help & Support', () => Navigator.pop(context)),
              _buildMenuItem(context, Icons.description_outlined, 'Terms & Conditions', () => Navigator.pop(context)),
              _buildMenuItem(context, Icons.privacy_tip_outlined, 'Privacy Policy', () => Navigator.pop(context)),
              
              SizedBox(height: 16),
              Divider(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.1)),
              SizedBox(height: 16),
              
              // --- Logout Button ---
              ListTile(
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
                leading: Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), shape: BoxShape.circle),
                  child: Icon(Icons.logout, color: Colors.red),
                ),
                title: Text('Logout', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red, fontSize: 16)),
                onTap: () {
                  Navigator.pop(context); // Close the bottom sheet
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        backgroundColor: Theme.of(context).colorScheme.surface,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                        title: Text('Logout', style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface)),
                        content: Text('Are you sure you want to log out?', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('Cancel', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.bold)),
                          ),
                          ElevatedButton(
                            onPressed: () async {
                              Navigator.pop(context);
                              await SessionManager.clearSession();
                              if (context.mounted) {
                                Navigator.of(context).pushAndRemoveUntil(
                                  MaterialPageRoute(builder: (_) => LoginScreen()),
                                  (route) => false,
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: Text('Logout', style: TextStyle(color: context.colors.cardBackground, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        return SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(1.0, 0.0),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
          child: child,
        );
      },
    );
  }

  Widget _buildMenuItem(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      leading: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.05),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: Theme.of(context).colorScheme.onSurface),
      ),
      title: Text(title, style: TextStyle(fontWeight: FontWeight.w600, color: Theme.of(context).colorScheme.onSurface, fontSize: 16)),
      trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Theme.of(context).colorScheme.onSurfaceVariant.withValues(alpha: 0.5)),
      onTap: onTap,
    );
  }

  void _showEditProfileDialog(BuildContext context) {
    final nameController = TextEditingController(text: SessionManager.userName);
    final idController = TextEditingController(text: SessionManager.memberId);
    final wardController = TextEditingController(text: SessionManager.userWard);
    final tierController = TextEditingController(text: SessionManager.userTier);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text('Edit Profile', style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    labelText: 'Name',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: idController,
                  decoration: InputDecoration(
                    labelText: 'Member ID',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: wardController,
                  decoration: InputDecoration(
                    labelText: 'Ward',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: tierController,
                  decoration: InputDecoration(
                    labelText: 'Tier',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              onPressed: () async {
                await SessionManager.setUserName(nameController.text);
                await SessionManager.setMemberId(idController.text);
                await SessionManager.setUserWard(wardController.text);
                await SessionManager.setUserTier(tierController.text);
                if (context.mounted) Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text('Save', style: TextStyle(color: Theme.of(context).colorScheme.onPrimary, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
