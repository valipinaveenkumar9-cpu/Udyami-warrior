import 'package:flutter/material.dart';
import 'package:uk_circle_partners/core/thems/app_colors.dart';
import 'package:flutter/services.dart';
import 'package:uk_circle_partners/features/auth/presentation/login_screen.dart';
import 'core/utils/session_manager.dart';
import 'core/services/background_location_service.dart';

final ValueNotifier<ThemeMode> appThemeNotifier = ValueNotifier(ThemeMode.light);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SessionManager.init();
  await BackgroundLocationService().initializeService();
  
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeNotifier,
      builder: (context, currentMode, _) {
        return MaterialApp(
          title: 'Channel Partner App',
          debugShowCheckedModeBanner: false,
          themeMode: currentMode,
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF1D4ED8),
              brightness: Brightness.light,
              background: const Color(0xFFFAFAFA),
              surface: context.colors.cardBackground,
              onBackground: const Color(0xFF0F172A),
              onSurface: const Color(0xFF0F172A),
            ),
            scaffoldBackgroundColor: const Color(0xFFFAFAFA),
            appBarTheme: AppBarTheme(
              backgroundColor: context.colors.cardBackground,
              foregroundColor: Color(0xFF0F172A),
              elevation: 0,
            ),
            useMaterial3: true,
            fontFamily: 'Roboto',
            extensions: <ThemeExtension<dynamic>>[
              AppColors.light,
            ],
          ),
          darkTheme: ThemeData(
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF1D4ED8),
              brightness: Brightness.dark,
              background: const Color(0xFF0F172A),
              surface: const Color(0xFF1E293B),
              onBackground: const Color(0xFFF8FAFC),
              onSurface: const Color(0xFFF8FAFC),
            ),
            scaffoldBackgroundColor: const Color(0xFF0F172A),
            appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xFF1E293B),
              foregroundColor: Color(0xFFF8FAFC),
              elevation: 0,
            ),
            bottomNavigationBarTheme:  BottomNavigationBarThemeData(
              backgroundColor: Color(0xFF1E293B),
              selectedItemColor: Color(0xFF3B82F6),
              unselectedItemColor: Color(0xFF94A3B8),
            ),
            useMaterial3: true,
            fontFamily: 'Roboto',
            extensions: <ThemeExtension<dynamic>>[
              AppColors.dark,
            ],
          ),
          home: const LoginScreen(),
        );
      },
    );
  }
}