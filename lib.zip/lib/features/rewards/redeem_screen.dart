import 'package:uk_circle_partners/core/widgets/custom_menu_drawer.dart';
import 'package:flutter/material.dart';
import 'package:uk_circle_partners/core/thems/app_colors.dart';
import 'package:uk_circle_partners/core/widgets/custom_app_bar.dart';

import '../home/presentation/main_screen.dart';

class RedeemScreen extends StatefulWidget {
  const RedeemScreen({super.key});

  @override
  State<RedeemScreen> createState() => _RedeemScreenState();
}

class _RedeemScreenState extends State<RedeemScreen> {
  int _selectedAmount = 4000;
  String _selectedDestination = 'upi'; // 'upi' or 'wallet'

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.pageBackground,
      appBar: CustomAppBar(),
      endDrawer: const CustomMenuDrawer(),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(16),
              children: [
                // Header Card
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: context.colors.cardBackground,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: context.colors.lightGreyBlue),
                  ),
                  child: Text(
                    'Redeem points',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: context.colors.primaryDarkBlue,
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // Amount Card
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: context.colors.cardBackground,
                    border: Border.all(color: context.colors.lightGreyBlue),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'How many points',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.1,
                          color: Color(0xFF5A6B87),
                        ),
                      ),
                      SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: context.colors.pageBackground,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: context.colors.lightGreyBlue),
                        ),
                        child: Text(
                          '$_selectedAmount',
                          style: TextStyle(
                            fontFamily: 'Barlow Condensed',
                            fontSize: 29,
                            fontWeight: FontWeight.bold,
                            color: context.colors.primaryDarkBlue,
                          ),
                        ),
                      ),
                      SizedBox(height: 12),
                      Row(
                        children: [
                          _buildAmountChip(2000, '2,000'),
                          SizedBox(width: 8),
                          _buildAmountChip(4000, '4,000'),
                          SizedBox(width: 8),
                          _buildAmountChip(4180, 'All 4,180'),
                        ],
                      ),
                      SizedBox(height: 12),
                      Text(
                        'Minimum 2,000 points',
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF5A6B87),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 12),

                // Destination Card
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: context.colors.cardBackground,
                    border: Border.all(color: context.colors.lightGreyBlue),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Where should it go',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.1,
                          color: Color(0xFF5A6B87),
                        ),
                      ),
                      SizedBox(height: 12),
                      _buildDestinationOption(
                        id: 'upi',
                        icon: '₹',
                        iconBg: context.colors.primaryDarkBlue,
                        iconColor: context.colors.cardBackground,
                        title: 'UPI — nikhil@okaxis',
                        subtitle: '2–3 working days',
                      ),
                      Divider(color: context.colors.lightGreyBlue, height: 24),
                      _buildDestinationOption(
                        id: 'wallet',
                        icon: '◈',
                        iconBg: context.colors.lightGreyBlue,
                        iconColor: context.colors.primaryDarkBlue,
                        title: 'Udyami coin wallet',
                        subtitle: 'Instant · use for membership',
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 12),

                // Calculation Card
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: context.colors.cardBackground,
                    border: Border.all(color: context.colors.lightGreyBlue),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('$_selectedAmount points at ₹0.50', style: TextStyle(fontSize: 13, color: context.colors.secondaryText)),
                          Text('₹${(_selectedAmount * 0.5).toStringAsFixed(2)}', style: TextStyle(fontSize: 13, color: context.colors.primaryDarkBlue)),
                        ],
                      ),
                      SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Tax deducted', style: TextStyle(fontSize: 13, color: context.colors.secondaryText)),
                          Text('−₹100.00', style: TextStyle(fontSize: 13, color: context.colors.primaryDarkBlue)),
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Divider(color: context.colors.lightGreyBlue, height: 1),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('You will receive', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: context.colors.primaryDarkBlue)),
                          Text(
                            '₹${((_selectedAmount * 0.5) - 100).toStringAsFixed(2)}',
                            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, fontFamily: 'Barlow Condensed', color: context.colors.primaryDarkBlue),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: context.colors.cardBackground,
            border: Border(top: BorderSide(color: Color(0xFFC9D2E0))),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Payout requested successfully!'),
                        backgroundColor: context.colors.greenSuccess,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => MainScreen()),
                      (route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: context.colors.primaryDarkBlue,
                    foregroundColor: context.colors.cardBackground,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(
                    'Request payout',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(height: 12),
              Text(
                'Ravi Kumar and Finance approve. Points are held until then.',
                style: TextStyle(fontSize: 11, color: Color(0xFF5A6B87)),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAmountChip(int amount, String label) {
    final isSelected = _selectedAmount == amount;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _selectedAmount = amount),
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? context.colors.primaryDarkBlue : context.colors.pageBackground,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: isSelected ? context.colors.primaryDarkBlue : context.colors.lightGreyBlue),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: isSelected ? context.colors.cardBackground : context.colors.primaryDarkBlue,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDestinationOption({
    required String id,
    required String icon,
    required Color iconBg,
    required Color iconColor,
    required String title,
    required String subtitle,
  }) {
    final isSelected = _selectedDestination == id;
    return InkWell(
      onTap: () => setState(() => _selectedDestination = id),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(8),
            ),
            alignment: Alignment.center,
            child: Text(
              icon,
              style: TextStyle(color: iconColor, fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: context.colors.primaryDarkBlue),
                ),
                SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 12, color: Color(0xFF5A6B87)),
                ),
              ],
            ),
          ),
          if (isSelected)
            Icon(Icons.check_circle, color: context.colors.greenSuccess, size: 20)
          else
            SizedBox(width: 20), // Placeholder for alignment
        ],
      ),
    );
  }
}
