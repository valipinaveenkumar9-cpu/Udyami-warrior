import 'package:uk_circle_partners/core/widgets/custom_menu_drawer.dart';
import 'package:flutter/material.dart';
import 'package:uk_circle_partners/core/thems/app_colors.dart';
import 'package:uk_circle_partners/core/widgets/custom_app_bar.dart';
import 'redeem_screen.dart';
import 'statement_screen.dart';

class RewardsScreen extends StatefulWidget {
  const RewardsScreen({super.key});

  @override
  State<RewardsScreen> createState() => _RewardsScreenState();
}

class _RewardsScreenState extends State<RewardsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.pageBackground,
      appBar: CustomAppBar(),
      endDrawer: const CustomMenuDrawer(),
      body: Column(
        children: [
          // FState Banner
          Container(
            color: Color(0xFFE4F1EA),
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(Icons.cloud_done_outlined, size: 16, color: context.colors.greenDark),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Up to date',
                    style: TextStyle(fontSize: 13, color: context.colors.greenDark, fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  '19:01',
                  style: TextStyle(fontSize: 11, color: context.colors.greenDark, fontFamily: 'monospace', fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),

          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Header Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: context.colors.cardBackground,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: context.colors.lightGreyBlue),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                              Text(
                              'Rewards',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: context.colors.primaryDarkBlue,
                              ),
                            ),
                            Text(
                              'CP-G33-0148 · Gold tier',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: context.colors.primaryDarkBlue,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => StatementScreen()),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          decoration: BoxDecoration(
                            color: context.colors.lightGreyBlue,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.receipt_long_outlined, size: 18, color: context.colors.primaryDarkBlue),
                              const SizedBox(width: 4),
                             
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // Main Balance Card
                Container(
                  padding: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                  decoration: BoxDecoration(
                    color: context.colors.primaryDarkBlue,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'You can redeem',
                        style: TextStyle(color: context.colors.chartAxis, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.1),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '4,180',
                        style: TextStyle(
                          color: context.colors.orangeWarning,
                          fontSize: 44,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Barlow Condensed',
                          height: 1,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'about ₹2,090',
                        style: TextStyle(color: context.colors.chartAxis, fontSize: 11, fontFamily: 'monospace'),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 12),

                // Three columns
                Row(
                  children: [
                    _buildSmallStatCard('Waiting to clear', '1,275', '6 Aug', valueColor: Color(0xFFB87A0E)),
                    SizedBox(width: 8),
                    _buildSmallStatCard('Being paid', '2,000', 'in approval'),
                    SizedBox(width: 8),
                    _buildSmallStatCard('Lifetime', '21.4k', 'since Feb'),
                  ],
                ),
                SizedBox(height: 12),

                // Warning Banner
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: context.colors.orangeLight,
                    border: Border.all(color: Color(0xFFEBCE8E)),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.warning_amber_rounded, size: 20, color: context.colors.orangeDark),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Daily limit reached — 25 invites',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: context.colors.orangeDark,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Today\'s extra invites are saved and will be verified, but they earn 0 points. The limit resets at midnight.',
                              style: TextStyle(fontSize: 12, color: context.colors.secondaryText, height: 1.4),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 12),

                // Multipliers Card
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: context.colors.cardBackground,
                    border: Border.all(color: context.colors.lightGreyBlue),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Why you earn more in Ward 33',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.1,
                          color: Color(0xFF5A6B87),
                        ),
                      ),
                      SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Low-penetration ward', style: TextStyle(fontSize: 13, color: context.colors.secondaryText)),
                          Text('× 1.50', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFFB87A0E))),
                        ],
                      ),
                      Divider(color: context.colors.lightGreyBlue, height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Gold tier', style: TextStyle(fontSize: 13, color: context.colors.secondaryText)),
                          Text('× 1.05', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFFB87A0E))),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: context.colors.cardBackground,
            border: Border(top: BorderSide(color: Color(0xFFC9D2E0))),
          ),
          child: SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RedeemScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: context.colors.orangeWarning,
                foregroundColor: Color(0xFF3A2A05),
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: Text(
                'Redeem points',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSmallStatCard(String label, String value, String subtitle, {Color? valueColor}) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: context.colors.cardBackground,
          border: Border.all(color: context.colors.lightGreyBlue),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: Color(0xFF5A6B87),
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                fontFamily: 'Barlow Condensed',
                color: valueColor ?? context.colors.primaryDarkBlue,
                height: 1,
              ),
            ),
            SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 9,
                color: Color(0xFF5A6B87),
                fontFamily: 'monospace',
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
