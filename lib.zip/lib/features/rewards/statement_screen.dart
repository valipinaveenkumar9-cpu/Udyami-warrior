import 'package:uk_circle_partners/core/widgets/custom_menu_drawer.dart';
import 'package:flutter/material.dart';
import 'package:uk_circle_partners/core/thems/app_colors.dart';
import 'package:uk_circle_partners/core/widgets/custom_app_bar.dart';
import 'redeem_screen.dart';

class StatementScreen extends StatelessWidget {
  StatementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.pageBackground,
      appBar: CustomAppBar(),
      endDrawer: const CustomMenuDrawer(),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // Statement Entries Card
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: context.colors.cardBackground,
              border: Border.all(color: context.colors.lightGreyBlue),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                _buildStatementRow(
                  title: 'Verified registration',
                  subtitle: 'Sunita B · Gandhi Bazaar · 31 Jul',
                  meta: '50 base + 25 profile × 1.50',
                  amount: '+113',
                  amountColor: context.colors.greenSuccess,
                ),
                Divider(color: context.colors.lightGreyBlue, height: 24),
                _buildStatementRow(
                  title: 'Path completed',
                  subtitle: 'Shankarapuram Beat 1 · 95%',
                  meta: 'E04 · bonus',
                  amount: '+200',
                  amountColor: context.colors.greenSuccess,
                ),
                Divider(color: context.colors.lightGreyBlue, height: 24),
                _buildStatementRow(
                  title: 'Referral activated',
                  subtitle: '+91 90XXX 41 · app opened again',
                  meta: 'E07 · tier 2',
                  amount: '+40',
                  amountColor: context.colors.greenSuccess,
                ),
                Divider(color: context.colors.lightGreyBlue, height: 24),
                _buildStatementRow(
                  title: 'Reversed — could not reach member',
                  subtitle: 'Kumar M · audit call on 28 Jul',
                  meta: 'reverses entry #84120',
                  amount: '−75',
                  amountColor: context.colors.redWarningDark,
                ),
                Divider(color: context.colors.lightGreyBlue, height: 24),
                _buildStatementRow(
                  title: 'Over daily limit',
                  subtitle: 'Vasanth K · invite 26 of the day',
                  meta: 'capped by DAILY_LEAD_25',
                  amount: '0',
                  amountColor: Color(0xFF5A6B87),
                ),
              ],
            ),
          ),
          SizedBox(height: 12),

          // Raise a question Card
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: context.colors.cardBackground,
              border: Border.all(color: context.colors.lightGreyBlue),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Something look wrong on a line?',
                  style: TextStyle(
                    fontSize: 14,
                    color: context.colors.primaryDarkBlue,
                  ),
                ),
                SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RedeemScreen(),
                        ),
                      );
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: context.colors.primaryDarkBlue,
                      side: BorderSide(color: Color(0xFFC9D2E0)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      'Raise a question',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            border: Border(top: BorderSide(color: context.colors.lightGreyBlue)),
            color: context.colors.cardBackground,
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(Icons.map_outlined, 'Paths', false),
                _buildNavItem(Icons.add_circle_outline, 'Invite', false),
                _buildNavItem(Icons.card_giftcard, 'Rewards', true),
                _buildNavItem(Icons.share_outlined, 'Refer', false),
                _buildNavItem(Icons.person_outline, 'Profile', false),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatementRow({
    required String title,
    required String subtitle,
    required String meta,
    required String amount,
    required Color amountColor,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: AppColors.light.primaryDarkBlue,
                ),
              ),
              SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF5A6B87),
                ),
              ),
              SizedBox(height: 2),
              Text(
                meta,
                style: TextStyle(
                  fontFamily: 'IBM Plex Mono',
                  fontSize: 9,
                  color: Color(0xFF5A6B87),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 8),
        Text(
          amount,
          style: TextStyle(
            fontFamily: 'Barlow Condensed',
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: amountColor,
          ),
        ),
      ],
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isSelected) {
    final color = isSelected ? AppColors.light.primaryDarkBlue : Color(0xFF5A6B87);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: color),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: color,
          ),
        ),
      ],
    );
  }
}
