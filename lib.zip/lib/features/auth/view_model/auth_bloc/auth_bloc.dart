import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/api/auth_api.dart';
import '../../../../core/utils/session_manager.dart';
import '../../../../core/utils/test_config.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  String? _currentMobileNumber;

  AuthBloc() : super(AuthInitial()) {
    on<SendOtpEvent>(_onSendOtp);
    on<VerifyOtpEvent>(_onVerifyOtp);
    on<LoginWithCpIdEvent>(_onLoginWithCpId);
    on<ResetAuthEvent>(_onResetAuth);
  }

  void _onLoginWithCpId(LoginWithCpIdEvent event, Emitter<AuthState> emit) async {
    print('DEV DEBUG - _onLoginWithCpId - auth_bloc.dart - Logging in CP ID: ${event.cpId}');
    emit(AuthLoading());

    // Mock Login Logic
    await Future.delayed(const Duration(seconds: 1));

    if (event.cpId.isNotEmpty && event.password == "123456") { // A simple mock check
      print('DEV DEBUG - _onLoginWithCpId - auth_bloc.dart - Mock Login Success');
      final mockUser = {
        'userId': 'mock-cp-1',
        'name': 'Mock CP User',
        'roles': ['CHANNEL_PARTNER'],
      };
      await SessionManager.saveSession('mock-cp-token', mockUser);
      emit(OtpVerifiedState()); // Reusing OtpVerifiedState for login success for now
    } else {
      print('DEV DEBUG - _onLoginWithCpId - auth_bloc.dart - Invalid CP ID or Password');
      emit(const AuthError('Invalid CP ID or Password (try password: 123456)'));
    }
  }

  void _onSendOtp(SendOtpEvent event, Emitter<AuthState> emit) async {
    print(
      'DEV DEBUG - _onSendOtp - auth_bloc.dart - Sending OTP for: ${event.mobileNumber} (isApplying: ${event.isApplying})',
    );
    emit(AuthLoading());

    // 1. Test numbers handling: Purely for OTP-free testing (yielding 123456)
    if (TestConfig.isTestNumber(event.mobileNumber)) {
      _currentMobileNumber = event.mobileNumber;
      print('DEV DEBUG - _onSendOtp - auth_bloc.dart - Test number allowed, providing free OTP 123456');
      emit(OtpSentState(event.mobileNumber, providedOtp: '123456', isTestMode: true));
      return;
    }

    // 2. Real numbers handling (Directly connected to the database)
    try {
      final authApi = AuthAPI();
      final exists = await authApi.checkUserExists(event.mobileNumber);

      if (event.isApplying) {
        // "Become a Channel Partner": If already registered in database, block and prompt to login
        if (exists) {
          print('DEV DEBUG - _onSendOtp - Mobile ${event.mobileNumber} already registered in DB. Blocking Apply.');
          emit(const AuthError('You already have an account as a Channel Partner. Please login to your account.'));
          return;
        }
      } else {
        // "Channel Partner Login": If not registered in database, block login and show popup
        if (!exists) {
          print('DEV DEBUG - _onSendOtp - Mobile ${event.mobileNumber} not found in DB. Blocking Login.');
          emit(const AuthError('Your number is not registered as a CP. Please go and apply here.'));
          return;
        }
      }

      final response = await authApi.sendOtp(event.mobileNumber, event.purpose);
      if (response != null && response['success'] == true) {
        _currentMobileNumber = event.mobileNumber;
        print(
          'DEV DEBUG - _onSendOtp - auth_bloc.dart - OTP sent successfully',
        );
        
        final rawOtp = response['otp']?.toString();
        final String? providedOtp = (rawOtp != null && rawOtp.isNotEmpty) ? rawOtp : null;
        
        emit(OtpSentState(event.mobileNumber, providedOtp: providedOtp));
      } else {
        emit(AuthError(response?['message'] ?? response?['error'] ?? 'Failed to send OTP'));
      }
    } catch (e) {
      emit(AuthError('Failed to send OTP: $e'));
    }
  }

  void _onVerifyOtp(VerifyOtpEvent event, Emitter<AuthState> emit) async {
    print(
      'DEV DEBUG - _onVerifyOtp - auth_bloc.dart - Verifying OTP: ${event.otp}',
    );
    if (_currentMobileNumber == null) {
      print(
        'DEV DEBUG - _onVerifyOtp - auth_bloc.dart - Error: No mobile number found',
      );
      emit(const AuthError('Something went wrong, please try again.'));
      return;
    }

    emit(AuthLoading());

    try {
      final authApi = AuthAPI();
      dynamic response;

      // Check if it's a test number to bypass verifyOtp
      if (TestConfig.isTestNumber(_currentMobileNumber!)) {
        if (event.otp != '123456') {
          emit(OtpVerificationError('Invalid OTP for test number (use 123456)', _currentMobileNumber!));
          return;
        }
        // Call loginUser directly with testMode
        response = await authApi.login(
          _currentMobileNumber!,
          otp: event.otp,
          testMode: true,
        );
      } else {
        // 1. Verify real-time OTP first via /auth/verify-otp (matches Kutumba)
        final verifyResponse = await authApi.verifyOtp(
          _currentMobileNumber!,
          event.otp,
          'LOGIN',
        );
        if (verifyResponse == null || verifyResponse['success'] != true) {
          final errorMsg = verifyResponse?['message'] ?? verifyResponse?['error'] ?? 'Invalid OTP';
          emit(OtpVerificationError(errorMsg, _currentMobileNumber!));
          return;
        }

        // 2. Call loginUser with OTP, verificationId, and testMode to get token (matches Kutumba)
        final verificationId = verifyResponse['verificationId']?.toString();
        final isTestMode = verifyResponse['testMode'] == true;
        response = await authApi.login(
          _currentMobileNumber!,
          otp: event.otp,
          verificationId: verificationId,
          testMode: isTestMode,
        );
      }

      if (response != null && response['success'] != false) {
        print(
          'DEV DEBUG - _onVerifyOtp - auth_bloc.dart - OTP verified via API successfully',
        );

        final token = response['accessToken'] as String?;
        final user = response['user'] as Map<String, dynamic>?;

        if (token != null && user != null) {
          // Extract roles for debug logging and RBAC
          final roles = user['roles'] as List<dynamic>? ?? [];
          final roleNames = roles.join(', ');
          print(
            'DEV DEBUG - _onVerifyOtp - auth_bloc.dart - Logged in User Roles: $roleNames',
          );

          if (!event.isApplying) {
            // RBAC Check: Ensure the user is a channel partner (strictly enforced from DB roles)
            bool isChannelPartner =
                roles.any(
                  (r) => r.toString().toLowerCase().contains('channel_partner'),
                ) ||
                (user['name']?.toString().toLowerCase().replaceAll(' ', '') ==
                    'channelpartner');

            if (!isChannelPartner) {
              print(
                'DEV DEBUG - _onVerifyOtp - auth_bloc.dart - RBAC Failed: User is not a channel partner',
              );
              emit(
                OtpVerificationError(
                  'Access Denied: This app is restricted to Channel Partners.',
                  _currentMobileNumber!,
                ),
              );
              return;
            }
          }

          await SessionManager.saveSession(token, user);
          print(
            'DEV DEBUG - _onVerifyOtp - auth_bloc.dart - Session saved locally',
          );
        }

        if (event.isApplying) {
          emit(OtpVerifiedForApplicationState());
        } else {
          emit(OtpVerifiedState());
        }
      } else {
        final errorMsg = response?['message'] ?? response?['error'] ?? 'Login failed after OTP verification';
        print('DEV DEBUG - _onVerifyOtp - auth_bloc.dart - Error: $errorMsg');
        emit(OtpVerificationError(errorMsg, _currentMobileNumber!));
      }
    } catch (e) {
      emit(
        OtpVerificationError(
          'OTP verification failed: $e',
          _currentMobileNumber!,
        ),
      );
    }
  }

  void _onResetAuth(ResetAuthEvent event, Emitter<AuthState> emit) {
    print('DEV DEBUG - _onResetAuth - auth_bloc.dart - Resetting Auth state');
    _currentMobileNumber = null;
    emit(AuthInitial());
  }
}
